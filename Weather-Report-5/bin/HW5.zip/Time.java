
public class Time {
	private int hour;
	 private int minute;
	 
	 public Time(int hour, int minute) {
		 this.hour = hour;
		 this.minute = minute;
	 }
	 
	 // getter for hour
	 public int getHour() {
		 return hour;
		 
	 }
	 
	 //getter for minute
	 public int getMinute() {
		 return minute;
	 }

}
